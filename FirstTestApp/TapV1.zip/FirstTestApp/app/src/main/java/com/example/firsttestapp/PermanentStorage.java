package com.example.firsttestapp;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

public class PermanentStorage {

    public static final String USER_KEY = "user";

    private static PermanentStorage permanentStorage;

    public static synchronized PermanentStorage getInstance() {
        if (permanentStorage == null) {
            permanentStorage = new PermanentStorage();
        }
        return permanentStorage;
    }

    public void storeString(Context context, String key, String value) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(key, value);
        editor.apply();
    }

    public String retrieveString(Context context, String key) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        String result = preferences.getString(key, "");
        return result;
    }


    }

