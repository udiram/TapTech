package com.example.firsttestapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class TechActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tech);
    }
}
