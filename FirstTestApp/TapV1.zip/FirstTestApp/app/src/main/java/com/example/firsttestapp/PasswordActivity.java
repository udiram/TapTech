package com.example.firsttestapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class PasswordActivity extends AppCompatActivity {
    private String correctPassword = "Udi";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password);

        Button login = findViewById(R.id.enter);
        final EditText enter = findViewById(R.id.password);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String result = enter.getText().toString();
                checkPassword(result);

                
            }
        });
    }
    private void doToast(String toastMessage) {
        LayoutInflater inflater = getLayoutInflater();
        View layout = inflater.inflate(R.layout.custom_toast,
                (ViewGroup) findViewById(R.id.custom_toast_container));

        TextView text = (TextView) layout.findViewById(R.id.text);
        text.setText(toastMessage);


        Toast toast = new Toast(getApplicationContext());
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setGravity(Gravity.BOTTOM|Gravity.RIGHT, 0, 0);
        toast.setView(layout);
        toast.show();
//        Toast toast = Toast.makeText(this, toastmessage, Toast.LENGTH_LONG);
//        toast.setGravity(Gravity.TOP|Gravity.RIGHT, 0, 0); //this is for changing where the toast pops up
//        toast.show();
    }
    private void checkPassword(String password) {
        if (password.equals(correctPassword)){
            doToast("Correct!");
            moveForward();
        }
        else {
            doToast("Try Again!");
        }
    }
    private void moveForward(){
        Intent moveForward = new Intent(this, ReportActivity.class);
        startActivity(moveForward);

    }
}
