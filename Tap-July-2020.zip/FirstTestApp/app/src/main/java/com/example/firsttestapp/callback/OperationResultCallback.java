package com.example.firsttestapp.callback;

public interface OperationResultCallback {

    void onOperationSuccess();
    void onOperationFailure();
}
